/*** Query 4. retrieves the columns ProductID, Name, Color
and ListPrice from the Production.Product table. 
the rows that arent NULL for the Color column. ***/


SELECT ProductID, Name, Color, ListPrice
  FROM Production.product
  where Color is not null