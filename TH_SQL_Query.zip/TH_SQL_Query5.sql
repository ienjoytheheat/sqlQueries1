/*** Query 5. retrieves the columns ProductID, Name, Color
and ListPrice from the Production.Product table. 
the rows that arent NULL for the Color column 
and listprice has value greater than 0. ***/


SELECT ProductID, Name, Color, ListPrice
  FROM Production.product
  where Color is not null AND ListPrice > 0
