/*** Query 6. a query that concatenates the columns Name and Color
from the Production.Product table by excluding the rows 
that are null for color. ***/


SELECT CONCAT(Name,'-', Color)
  FROM Production.product
  where Color is not null