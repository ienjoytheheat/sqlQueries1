/*** Query 13. retrieve rows that have a Name that begins with the letters SPO, but is then not followed by the letter K.
After this zero or more letters can exists. Order the result set by the Name column.***/


SELECT Name
  FROM Production.product
  where Name like 'SPO%' and Name not like '___k%'
  order by Name
