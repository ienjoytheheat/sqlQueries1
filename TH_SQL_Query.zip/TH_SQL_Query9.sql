/*** Query 9. retrieves the to the columns  ProductID, Name and color from the
Production.Product table restricted to the colors black and blue ***/


SELECT ProductID, Name, Color
  FROM Production.product
  where Color = 'black' or Color = 'blue'
