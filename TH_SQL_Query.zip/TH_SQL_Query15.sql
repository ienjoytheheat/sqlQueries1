/*** Query 15. etrieves the unique combination of columns ProductSubcategoryID
and Color from the Production.Product table. Format and sort so the result
set accordingly to the following. We do not want any rows that are NULL. 
in any of the two columns in the result. ***/


SELECT distinct ProductSubcategoryID, Color
  FROM Production.product
 
 where ProductSubcategoryID is not null AND color is not null