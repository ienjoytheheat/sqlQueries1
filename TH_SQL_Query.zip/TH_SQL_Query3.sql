/*** Query 3. retrieves the columns ProductID, Name, Color
and ListPrice from the Production.Product table. 
the rows that are NULL for the Color column. ***/


SELECT ProductID, Name, Color, ListPrice
  FROM Production.product
  where Color is null