/*** Query 7. custom query ***/


SELECT CONCAT('NAME:',Name,'-- COLOR:', Color)
  FROM Production.product
  where Name like '%chainring%' or name like '%crankarm%'
