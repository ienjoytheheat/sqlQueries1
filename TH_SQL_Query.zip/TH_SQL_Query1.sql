/*** Query 1. retrieves the columns ProductID, Name, Color
and ListPrice from the Production.Product table, with no filter.  ***/

SELECT ProductID, Name, Color, ListPrice
  FROM Production.product