/*** Query 8. query to retrieve the columns ProductID and Name
from the Production.Product table filtered by
ProductID from 400 to 500. ***/


SELECT ProductID, Name
  FROM Production.product
  where ProductID between 400 and 500
