/*** Query 14. retrieves unique colors from the table Production.Product. Order the results  in descending  manner***/


SELECT distinct Color
  FROM Production.product

  order by Color desc