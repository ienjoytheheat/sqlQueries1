/*** Query 12. retrieves product names that start with 'S' or 'A' and is ordered by NAME ***/


SELECT Name, ListPrice
  FROM Production.product
  where name like 's%' or name like 'a%'
  order by Name
