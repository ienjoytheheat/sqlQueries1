/*** Query 11. retrieves product names that start with 'S' and is ordered by NAME ***/


SELECT Name, ListPrice
  FROM Production.product
  where name like 's%'
  order by Name
