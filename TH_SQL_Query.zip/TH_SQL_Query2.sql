/*** Query 2. retrieves the columns ProductID, Name, Color
and ListPrice from the Production.Product table.
excludes the rows that ListPrice is 0. ***/


SELECT ProductID, Name, Color, ListPrice
  FROM Production.product
  where ListPrice != 0
